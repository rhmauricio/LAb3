//Declaracion de variables globales

x="0"; //guardar número en pantalla
xi=1; //iniciar número en pantalla: 1=si; 0=no;
coma=0; //estado coma decimal 0=no, 1=si;
ni=0; //número oculto o en espera.
op="no"; //operación en curso; "no" =  sin operación.
tipo="deg";
temaglobal=1;
globalvariabl=2;
inverso=0;
memoria="";
vector= new Array();
i=0;
aux="";
//Acciones tras cargar la página
window.onload = function(){ 
pantalla0=document.getElementById("display-div0");
pantalla1=document.getElementById("display-div1"); 
pantalla0.innerHTML="Ans = 0";
pantalla1.innerHTML=0;
document.getElementById("deg").style.backgroundColor = "green";
};

//recoge el número pulsado en el argumento.
function numero(xx) { 
	
   memoria+=String(xx); // mostrar en pantalla 
   vector[i]=xx;
  
   i++;
	if (x=="0" || xi==1  ) { // inicializar un número, 
	pantalla1.innerHTML=memoria; //mostrar en pantalla
	x=xx;
	//guardar número
		if (xx==".") { //si escribimos una coma al principio del número
			pantalla1.innerHTML="0"+memoria; //escribimos 0.
			x=xx; //guardar número
			coma=1; //cambiar estado de la coma	
        }
    }
    else { //continuar escribiendo un número
            if (xx=="." && coma==0) { //si escribimos una coma decimal por primera vez
                pantalla1.innerHTML=memoria;
                x+=xx;
                coma=1; //cambiar el estado de la coma  
            }
              //si intentamos escribir una segunda coma decimal no realiza ninguna acción.
            else if (xx=="." && coma==1) {} 
            //Resto de casos: escribir un número del 0 al 9: 	 
            else {
               pantalla1.innerHTML=memoria;
                x+=xx
            }
    }
            xi=0 //el número está iniciado 
  }

 
function parentesis(valor){//Mostrar parentesis 
		if(valor==1){
			memoria+="(";
			vector[i]="(";
			alert(vector[i]);
			i++;
			pantalla1.innerHTML=memoria;
			
		}else if(valor==2){
			memoria+=")";
			pantalla1.innerHTML=memoria;
			vector[i]=")";
			alert(vector[i]);
			i++;
		}
}  

//tipo de operacion
function operacion(s) {
		if(s=="sin" && inverso==1){
			memoria+="a"+String(s)+"(";//Caracter de operacion 
			vector[i]="a"+String(s)+"(";
			i++;
		}else if(s=="sin" && inverso==0){
			memoria+=String(s)+"(";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
			
		}else if(s=="ln" && inverso==1){
			memoria+="e"+"^"+"(";//Caracter de operacion 
			vector[i]="e";//no importa el ^
			i++;
			vector[i]="(";
			i++;
		}else if(s=="ln" && inverso==0){
			memoria+=String(s)+"(";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="cos" && inverso==1){
			memoria+="a"+String(s)+"(";//Caracter de operacion 
			vector[i]="a"+String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="cos" && inverso==0){
			memoria+=String(s)+"(";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="log" && inverso==1){
			memoria+="10"+"^"+"(";//Caracter de operacion 
			vector[i]="10";//no importa el ^
			i++;
			vector[i]="(";
			i++;
		}else if(s=="log" && inverso==0){
			memoria+=String(s)+"(";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="tan" && inverso==1){
			memoria+="a"+String(s)+"(";//Caracter de operacion 
			vector[i]="a"+String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="tan" && inverso==0){
			memoria+=String(s)+"(";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="sqr" && inverso==1){
			memoria+="^"+"2";//Caracter de operacion 
			vector[i]="a"+String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="sqr" && inverso==0){
			memoria+="√"+"(";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="exp"){
			memoria+="E";
			vector[i]="E";
			i++;
		}else if(s=="elevado" && inverso==1){
			memoria+="^";//Caracter de operacion 
			vector[i]="invele";
			i++;
		}else if(s=="elevado" && inverso==0){
			memoria+="^";//Caracter de operacion 
			vector[i]=String(s);
			i++;
			vector[i]="(";
			i++;
		}else if(s=="factorial"){
			memoria+="!";//Caracter de operacion 
			vector[i]=String(s);
			i++;
		}else{
		memoria+=String(s);//Caracter de operacion 
		vector[i]=String(s);
		i++;
		
		}
		pantalla1.innerHTML=memoria;
		xi=1; //inicializar pantalla.
        }
  
// teclas funcionales 


	
function igualar() {
			/*
			//sl=Number(memoria) // escribimos la operación en una cadena
            sol=eval(memoria) //convertimos la cadena a código y resolvemos
			alert(sol);
            x=sol; //guardamos la solución
            op="no"; //ya no hay operaciones pendientes
            xi=1; //se puede reiniciar la pantalla.*/
			var aux1=numeroParentesis();
			 a= new Array();
		 k=0;
		 for(i=0; i<vector.length;i++){
			if(vector[i]=="("){
				a[k]=i;
				k++;
			}
		};
		b=a[k]+1;
		while(a[k]>=0){
				do{
				aux_vector+=vector[b];
				alert(aux_vector);
				vector[b]=0;
				b++;
				}while(vector[b]==")");
				vector[b]=0;
				b=a[k];
				vector[b]=solve(aux_vector);
				k--;
			}
			alert(a);
			alert(b);
			document.getElementById("arcsin").innerHTML = "sin";
			document.getElementById("expodiez").innerHTML = "ln";
			document.getElementById("arccos").innerHTML = "cos";
			document.getElementById("loginv").innerHTML = "log";
			document.getElementById("arctan").innerHTML = "tan";
			document.getElementById("razinv").innerHTML = "√";
			document.getElementById("elevinv").innerHTML = "x<sup>y</sup>";
			document.getElementById("prueba").innerHTML = "Ans";
			inverso=0;
			i=0;
	}
 
 function borrar(){
		pantalla0.innerHTML="Ans = "+x;
		pantalla1.innerHTML=0;
		x="0"; //guardar número en pantalla
		xi=1; //iniciar número en pantalla: 1=si; 0=no;
		coma=0; //estado coma decimal 0=no, 1=si;
		init=false;
		ni=0; //número oculto o en espera.
		op="no"
		memoria="";
	 i=0;
 }
 

function porcent() { 
         x=x/100 //dividir por 100 el número
         pantalla1.innerHTML=x; //mostrar en pantalla
         igualar() //resolver y mostrar operaciones pendientes
         xi=1 //reiniciar la pantalla
         }
		 
		 
function inve() {
	inverso=1;
	document.getElementById("arcsin").innerHTML = "sin<sup>-1</sup>";
	document.getElementById("expodiez").innerHTML = "e<sup>x</sup>";
	document.getElementById("arccos").innerHTML = "cos<sup>-1</sup>";
	document.getElementById("loginv").innerHTML = "10<sup>x</sup>";
	document.getElementById("arctan").innerHTML = "tan<sup>-1</sup>";
	document.getElementById("razinv").innerHTML = "x<sup>2</sup>";
	document.getElementById("elevinv").innerHTML = "<sup>y</sup>√x";	
	document.getElementById("prueba").innerHTML = "Rnd";
}
        
		 
function factorial(){
	n=Number(x);
	var total = 1; 
	for (i=1; i<=n; i++) {
		total = total * i; 
	}
	x=String(total);	
	pantalla0.innerHTML=n+"!=";	
	pantalla1.innerHTML=x;	
}

	
function funAns(){
		memoria="Ans";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
		if(inverso==1){nx=Math.random(nx);}
		else{nx=sol;}
		x=String(nx);		 
		pantalla1.innerHTML=x;
		igualar();
		xi=1; 
}
function rad(value){ //cambiar de raidanes a grados o de grados a radianes 
	if(value=="rad"){//verificacion de la peticion 
		globalvariabl=1;//bandera para indicar que esta en rad
		//cambio de colores en las teclas 
		document.getElementById("rad").style.backgroundColor = "green";
		if(temaglobal==1){
		document.getElementById("deg").style.backgroundColor = "#414141";
		}else{
		document.getElementById("deg").style.backgroundColor = "red";
		}
	}
	else if(value=="deg"){
		globalvariabl=2;//bandera para indicar que esta en deg
		//cambio de colores en las teclas 
		document.getElementById("deg").style.backgroundColor = "green";
		if(temaglobal==1){
		document.getElementById("rad").style.backgroundColor = "#414141";
		}else{
		document.getElementById("rad").style.backgroundColor = "red";
		}
	}
}
//Cambio de estilos
function cambiotema(tema){
	temaglobal=tema;
	document.getElementById("tema1").href=`../css/style${tema}.css`;
	if(temaglobal==1){
		if(globalvariabl==1){document.getElementById("deg").style.backgroundColor = "#414141";}
		else{document.getElementById("rad").style.backgroundColor = "#414141";}
			
	}else{
		if(globalvariabl==2){document.getElementById("rad").style.backgroundColor = "red";}
		else{document.getElementById("deg").style.backgroundColor = "red";}	
	}
	
}
function numeroParentesis(){
			j=0;
			a=0;
			b=0;
			for(j=0;j<i;j++){
				if(vector[j]=="("){
					a++;
				}else if(vector[j]==")"){
					b++;
				}
			};
	if(a!=b){
		alert("error de parentesis ")
		
	}
	return a;
}