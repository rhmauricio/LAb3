//Declaracion de variables globales

x="0"; //guardar número en pantalla
xi=1; //iniciar número en pantalla: 1=si; 0=no;
coma=0; //estado coma decimal 0=no, 1=si;
ni=0; //número oculto o en espera.
op="no"; //operación en curso; "no" =  sin operación.
tipo="deg";
temaglobal=1;
globalvariabl=2;
inverso=0;
memoria="";


//Acciones tras cargar la página
window.onload = function(){ 
pantalla0=document.getElementById("display-div0");
pantalla1=document.getElementById("display-div1"); 
pantalla0.innerHTML="Ans = 0";
pantalla1.innerHTML=0;
document.getElementById("deg").style.backgroundColor = "green";
};

//recoge el número pulsado en el argumento.
function numero(xx) { 
   memoria+=String(xx); // mostrar en pantalla 
	if (x=="0" || xi==1  ) { // inicializar un número, 
	pantalla1.innerHTML=memoria; //mostrar en pantalla
	x=xx; //guardar número
		if (xx==".") { //si escribimos una coma al principio del número
			pantalla1.innerHTML="0"+memoria; //escribimos 0.
			x=xx; //guardar número
			coma=1; //cambiar estado de la coma	
        }
    }
    else { //continuar escribiendo un número
            if (xx=="." && coma==0) { //si escribimos una coma decimal por primera vez
                pantalla1.innerHTML=memoria;
                x+=xx;
                coma=1; //cambiar el estado de la coma  
            }
              //si intentamos escribir una segunda coma decimal no realiza ninguna acción.
            else if (xx=="." && coma==1) {} 
            //Resto de casos: escribir un número del 0 al 9: 	 
            else {
               pantalla1.innerHTML=memoria;
                x+=xx
            }
    }
            xi=0 //el número está iniciado 
  }

 
function parentesis(valor){//Mostrar parentesis 
		if(valor==1){
			memoria+="(";
			pantalla1.innerHTML=memoria;
		}else if(valor==2){
			memoria+=")";
			pantalla1.innerHTML=memoria;
		}
}  

//tipo de operacion
function operacion(s) {
		memoria+=String(s);//Caracter de operacion 
		pantalla1.innerHTML=memoria;//mostrar en pantalla 
        igualar('1'); //si hay operaciones pendientes se realizan primero
        ni=x; //ponemos el 1º número en "numero en espera" para poder escribir el segundo.
        op=s; //guardamos tipo de operación.
        xi=1; //inicializar pantalla.
        }
  
// teclas funcionales 

function rad(value){ //cambiar de raidanes a grados o de grados a radianes 
	if(value=="rad"){//verificacion de la peticion 
		globalvariabl=1;//bandera para indicar que esta en rad
		//cambio de colores en las teclas 
		document.getElementById("rad").style.backgroundColor = "green";
		if(temaglobal==1){
		document.getElementById("deg").style.backgroundColor = "#414141";
		}else{
		document.getElementById("deg").style.backgroundColor = "red";
		}
	}
	else if(value=="deg"){
		globalvariabl=2;//bandera para indicar que esta en deg
		//cambio de colores en las teclas 
		document.getElementById("deg").style.backgroundColor = "green";
		if(temaglobal==1){
		document.getElementById("rad").style.backgroundColor = "#414141";
		}else{
		document.getElementById("rad").style.backgroundColor = "red";
		}
	}
}
	
function igualar(value) {
	
	if(value=='1'){
         if (op=="no") { //no hay ninguna operación pendiente.
            pantalla1.innerHTML=memoria;//mostramos el mismo número	
            }
		else if(op=="exp"){
			pantalla1.innerHTML=0;	
		}
         else { //con operación pendiente resolvemos
            sl=ni+op+x; // escribimos la operación en una cadena
            sol=eval(sl) //convertimos la cadena a código y resolvemos
            x=sol; //guardamos la solución
            op="no"; //ya no hay operaciones pendientes
            xi=1; //se puede reiniciar la pantalla.
			
			}
			document.getElementById("arcsin").innerHTML = "sin";
			document.getElementById("expodiez").innerHTML = "ln";
			document.getElementById("arccos").innerHTML = "cos";
			document.getElementById("loginv").innerHTML = "log";
			document.getElementById("arctan").innerHTML = "tan";
			document.getElementById("razinv").innerHTML = "√";
			document.getElementById("elevinv").innerHTML = "x<sup>y</sup>";
			document.getElementById("prueba").innerHTML = "Ans";
			inverso=0;
	}else{	
		sl=ni+op+x; // escribimos la operación en una cadena
        sol=eval(sl) //convertimos la cadena a código y resolvemos
        x=sol; //guardamos la solución
        op="no"; //ya no hay operaciones pendientes
        xi=1; //se puede reiniciar la pantalla.
		pantalla1.innerHTML=x; //mostramos la solución
		pantalla0.innerHTML=memoria+"=";
		memoria="";
		sol=0;
		}
}
 
 function borrar(){
		pantalla0.innerHTML="Ans = "+x;
		pantalla1.innerHTML=0;
		x="0"; //guardar número en pantalla
		xi=1; //iniciar número en pantalla: 1=si; 0=no;
		coma=0; //estado coma decimal 0=no, 1=si;
		init=false;
		ni=0; //número oculto o en espera.
		op="no"
		memoria="";
	 
 }
 
 function raizc() {
		if(inverso==1){x=Math.pow(x,2);}
        else{x=Math.sqrt(x)} //resolver raíz cuadrada.
        pantalla1.innerHTML=x; //mostrar en pantalla resultado
        op="no"; //quitar operaciones pendientes.
		igualar();
        xi=1; //se puede reiniciar la pantalla 
		 
         }
		 
function porcent() { 
         x=x/100 //dividir por 100 el número
         pantalla1.innerHTML=x; //mostrar en pantalla
         igualar() //resolver y mostrar operaciones pendientes
         xi=1 //reiniciar la pantalla
         }
		 
		 
function inve() {
	inverso=1;
	document.getElementById("arcsin").innerHTML = "sin<sup>-1</sup>";
	document.getElementById("expodiez").innerHTML = "e<sup>x</sup>";
	document.getElementById("arccos").innerHTML = "cos<sup>-1</sup>";
	document.getElementById("loginv").innerHTML = "10<sup>x</sup>";
	document.getElementById("arctan").innerHTML = "tan<sup>-1</sup>";
	document.getElementById("razinv").innerHTML = "x<sup>2</sup>";
	document.getElementById("elevinv").innerHTML = "<sup>y</sup>√x";	
	document.getElementById("prueba").innerHTML = "Rnd";
}
        
		 
function factorial(){
	memoria="!";
	pantalla1.innerHTML=memoria;
	n=Number(x);
	var total = 1; 
	for (i=1; i<=n; i++) {
		total = total * i; 
	}
	x=String(total);		 
    pantalla1.innerHTML=x;
	igualar();
    xi=1; //reiniciar pantalla al pulsar otro número.
	
}

function seno(){
		nx=Number(x);
		if(globalvariabl==1){nx=nx *( Math.PI / 180);}
		if(inverso==1){
			memoria+="asin(";
		pantalla1.innerHTML=memoria;
			nx=Math.asin(nx);
			}
        else{
			memoria+="sin(";
			pantalla1.innerHTML=memoria;
			nx=Math.sin(nx);
		}
        x=String(nx);		 
		inverso=0;
        xi=1; //reiniciar pantalla al pulsar otro número.
}
function lognat(){
		memoria="ln(";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
		if(inverso==1){nx=Math.pow(Math.E,nx);}
        else{nx=Math.log(nx)};
        x=String(nx);		 
        pantalla1.innerHTML=x;
		igualar();
        xi=1; //reiniciar pantalla al pulsar otro número.
		inverso=0;
}
function euler(){
		memoria="e^";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
        nx=Math.E;
        x=String(nx);		 
        pantalla1.innerHTML=x;
		igualar();
        xi=1; //reiniciar pantalla al pulsar otro número.
}
function coseno(){
		memoria="cos(";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
		if(globalvariabl==1){nx=nx *( Math.PI / 180);}
		if(inverso==1){nx=Math.acos(nx);}
		else{nx=Math.cos(nx);}
        x=String(nx);		 
        pantalla1.innerHTML=x;
		igualar();
        xi=1; //reiniciar pantalla al pulsar otro número.
}
function logaritmo(){
		memoria="log(";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
		if(inverso==1){nx=Math.pow(10,nx);}
        else{nx=Math.log10(nx)};
        x=String(nx);		 
        pantalla1.innerHTML=x;
		igualar();
        xi=1; //reiniciar pantalla al pulsar otro número.
}
function tangente(){
		memoria="tan(";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
		if(globalvariabl==1){nx=nx *( Math.PI / 180);}
		if(inverso==1){nx=Math.atan(nx);}
        else{nx=Math.tan(nx);}
        x=String(nx);		 
        pantalla1.innerHTML=x;
		igualar();
        xi=1; //reiniciar pantalla al pulsar otro número.
}
function exponente(){
		memoria="E";
		pantalla1.innerHTML=memoria;
		igualar(); //si hay operaciones pendientes se realizan primero
		ni=x; //ponemos el 1º número en "numero en espera" para poder escribir el segundo.
        op="exp"; //guardamos tipo de operación.
        xi=1; //inicializar pantalla.
		nx=Number(ni);
		x=Number(x);
		sol=nx*Math.exp(x); // escribimos la operación en una cadena
		sol=String(sol);
}
function elevado(){
		nx=Number(x);
		if(inverso==1){nx=Math.pow(nx);}
        else{nx=Math.pow(nx);}
		x=String(nx);
}		
		
function funAns(){
		memoria="Ans";
		pantalla1.innerHTML=memoria;
		nx=Number(x);
		if(inverso==1){nx=Math.random(nx);}
		else{nx=sol;}
		x=String(nx);		 
		pantalla1.innerHTML=x;
		igualar();
		xi=1; 
}

//Cambio de estilos
function cambiotema(tema){
	temaglobal=tema;
	document.getElementById("tema1").href=`../css/style${tema}.css`;
	if(temaglobal==1){
		if(globalvariabl==1){document.getElementById("deg").style.backgroundColor = "#414141";}
		else{document.getElementById("rad").style.backgroundColor = "#414141";}
			
	}else{
		if(globalvariabl==2){document.getElementById("rad").style.backgroundColor = "red";}
		else{document.getElementById("deg").style.backgroundColor = "red";}	
	}
	
}
